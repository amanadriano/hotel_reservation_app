//boilerplate
define([
	'jquery',
	'underscore',
	'backbone',
	'handlebars'
], function($, _, Backbone, Handlebars) {
	
	return {};

});
