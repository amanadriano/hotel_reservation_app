-- Adminer 3.6.4 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = '+08:00';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `res`;
CREATE DATABASE `res` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `res`;

DROP TABLE IF EXISTS `charges`;
CREATE TABLE `charges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `amount` mediumint(8) unsigned NOT NULL,
  `qty` smallint(5) unsigned NOT NULL,
  `qty_cost` mediumint(8) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `action` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checkinId` bigint(20) unsigned NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `checkinId` (`checkinId`),
  CONSTRAINT `charges_ibfk_2` FOREIGN KEY (`checkinId`) REFERENCES `checkins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `charges` (`id`, `description`, `amount`, `qty`, `qty_cost`, `name`, `action`, `checkinId`, `date`) VALUES
(1,	'room charge',	1100,	1,	1100,	'Room Charge',	1,	1,	'2013-02-10 00:00:00'),
(2,	'drinks, beverages (mixed)',	250,	5,	50,	'Mini Bar',	0,	1,	'2013-02-13 00:00:00'),
(3,	'credit card. 1654987321654968789',	59650,	1,	59650,	'Payment',	3,	1,	'2013-04-05 00:00:00'),
(6,	'pay',	1800,	1,	1800,	'Payment',	3,	2,	'2013-02-12 00:00:00'),
(8,	'',	0,	1,	0,	'Room Charge',	2,	2,	'2013-02-12 00:00:00'),
(9,	'',	900,	1,	900,	'Room Charge',	1,	2,	'2013-02-10 00:00:00'),
(10,	'cash',	4000,	1,	4000,	'Payment',	3,	1,	'2013-04-09 00:00:00'),
(11,	'',	0,	1,	0,	'Room Charge',	2,	1,	'2013-04-09 00:00:00'),
(12,	'',	400,	1,	400,	'Payment',	3,	1,	'2013-04-09 00:00:00'),
(22,	'Deposit received during reservation.',	50000,	1,	50000,	'Payment',	3,	7,	'2013-05-04 00:00:00'),
(23,	'',	120000,	1,	120000,	'Room Charge',	1,	3,	'2013-04-12 00:00:00'),
(24,	'',	120000,	1,	120000,	'Room Charge',	1,	7,	'2013-05-04 00:00:00'),
(25,	'',	120000,	1,	120000,	'Room Charge',	1,	4,	'2013-04-27 00:00:00'),
(26,	'',	1030000,	1,	1030000,	'Payment',	3,	7,	'2013-05-13 00:00:00'),
(28,	'pancit',	37500,	3,	12500,	'Restaurant',	0,	3,	'2013-05-15 08:37:00'),
(29,	'cash payment',	3000000,	1,	3000000,	'Payment',	3,	3,	'2013-05-15 13:32:00'),
(30,	'cash',	1597500,	1,	1597500,	'Payment',	3,	3,	'2013-05-19 22:37:00'),
(31,	'Room Charge',	50000,	1,	50000,	'Room Charge',	1,	8,	'2013-05-23 08:09:00');

DROP TABLE IF EXISTS `checkins`;
CREATE TABLE `checkins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guestId` bigint(20) unsigned NOT NULL,
  `checkIn` datetime NOT NULL,
  `checkOut` datetime NOT NULL,
  `roomId` smallint(5) unsigned NOT NULL,
  `status` varchar(20) DEFAULT NULL,
  `roomPrice` mediumint(8) unsigned NOT NULL,
  `pax` smallint(5) unsigned NOT NULL,
  `children` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `guestId` (`guestId`),
  CONSTRAINT `checkins_ibfk_1` FOREIGN KEY (`guestId`) REFERENCES `guests` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `checkins` (`id`, `guestId`, `checkIn`, `checkOut`, `roomId`, `status`, `roomPrice`, `pax`, `children`) VALUES
(1,	4,	'2013-02-10 00:00:00',	'2013-04-11 00:00:00',	1,	'OUT',	1100,	3,	1),
(2,	5,	'2013-02-10 00:00:00',	'2013-02-12 00:00:00',	2,	'OUT',	0,	3,	1),
(3,	4,	'2013-04-12 11:13:00',	'2013-05-19 22:38:00',	1,	'OUT',	120000,	1,	0),
(4,	4,	'2013-04-27 10:17:00',	'2013-04-30 00:00:00',	1,	'IN',	120000,	1,	0),
(7,	4,	'2013-05-04 00:00:00',	'2013-05-13 12:00:00',	1,	'OUT',	120000,	2,	1),
(8,	14,	'2013-05-23 08:09:00',	'2013-05-30 12:00:00',	29,	'IN',	50000,	2,	0);

DROP TABLE IF EXISTS `guests`;
CREATE TABLE `guests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(250) NOT NULL,
  `citizenship` varchar(200) NOT NULL,
  `dob` datetime NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `company` varchar(200) NOT NULL,
  `position` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `guests` (`id`, `fullname`, `citizenship`, `dob`, `contact_no`, `email`, `company`, `position`) VALUES
(4,	'Aman Jake L. Adriano',	'Filipino',	'2009-07-17 00:00:00',	'09184030903',	'secondrnd@gmail.com',	'Leon, Inc.',	'Baby'),
(5,	'Leon Thomas F. Adriano',	'Filipino',	'2009-07-17 00:00:00',	'0123456789',	'leonthomas@gmail.com',	'Leon, Inc.',	'Baby'),
(11,	'Rodellaine Flordeliza',	'Filipino',	'1982-09-10 00:00:00',	'09085422146',	'',	'',	''),
(12,	'el NiÃ‘o',	'filipino',	'1981-12-02 00:00:00',	'12341234',	'',	'',	''),
(13,	'asdf',	'asdf',	'1980-12-02 00:00:00',	'adsfasdf',	'',	'',	''),
(14,	'superman',	'test',	'1981-12-02 00:00:00',	'09140192341234',	'',	'',	''),
(15,	'mc donald',	'pinoy',	'1970-01-01 08:00:00',	'123412341234',	'',	'',	'');

DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `checkinId` bigint(20) unsigned NOT NULL,
  `paymentDate` datetime NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `method` varchar(50) NOT NULL,
  `info` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `checkinId` (`checkinId`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`checkinId`) REFERENCES `checkins` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `reservations`;
CREATE TABLE `reservations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guestId` bigint(20) unsigned NOT NULL,
  `checkin` datetime NOT NULL,
  `checkout` datetime NOT NULL,
  `roomId` mediumint(8) unsigned NOT NULL,
  `status` varchar(20) NOT NULL,
  `pax` smallint(5) unsigned NOT NULL,
  `children` smallint(5) unsigned NOT NULL,
  `deposit` mediumint(8) unsigned NOT NULL,
  `roomPrice` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `guestId` (`guestId`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`guestId`) REFERENCES `guests` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `reservations` (`id`, `guestId`, `checkin`, `checkout`, `roomId`, `status`, `pax`, `children`, `deposit`, `roomPrice`) VALUES
(2,	12,	'2013-05-13 00:00:00',	'2013-05-17 00:00:00',	3,	'RES',	2,	1,	100000,	160000),
(3,	4,	'2013-05-25 00:00:00',	'2013-05-29 00:00:00',	3,	'RES',	1,	0,	60000,	160000),
(4,	15,	'2013-05-24 09:00:00',	'2013-05-26 09:00:00',	1,	'RES',	1,	0,	80000,	120000),
(5,	15,	'2013-05-25 23:08:00',	'2013-05-31 00:00:00',	2,	'RES',	1,	0,	150000,	90000);

DROP TABLE IF EXISTS `rooms`;
CREATE TABLE `rooms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `roomNo` smallint(5) unsigned NOT NULL,
  `roomType` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roomNo` (`roomNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `rooms` (`id`, `roomNo`, `roomType`, `description`, `price`) VALUES
(1,	1,	'DELUXE',	'1 Bed, Aircon, Tv, Bathroom',	120000),
(2,	10,	'SINGLE',	'Single Bed, Good for 1 person only.',	90000),
(3,	2,	'Deluxe',	'Deluxe Room, Double Bed',	160000),
(29,	3,	'Standard',	'Standard room, standard bed, standard food, standard everything',	50000);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` char(40) NOT NULL,
  `permission` tinyint(4) NOT NULL,
  `last_log` datetime NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `username`, `password`, `permission`, `last_log`, `date_created`) VALUES
(1,	'amanadriano',	'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3',	2,	'2013-05-24 14:57:33',	'2013-05-19 08:40:20'),
(7,	'leonthomas',	'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3',	1,	'2013-05-23 12:56:34',	'2013-05-19 09:23:06'),
(8,	'admin',	'd033e22ae348aeb5660fc2140aec35850c4da997',	3,	'2013-05-23 16:36:51',	'2013-05-22 16:49:43');

-- 2013-05-24 16:28:13
