-- Adminer 3.6.1 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `charges`;
CREATE TABLE `charges` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `due` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `checkins`;
CREATE TABLE `checkins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guestId` bigint(20) unsigned NOT NULL,
  `checkin` datetime NOT NULL,
  `checkout` datetime NOT NULL,
  `roomId` int(11) NOT NULL,
  `status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `guestId` (`guestId`),
  CONSTRAINT `checkins_ibfk_1` FOREIGN KEY (`guestId`) REFERENCES `guests` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `guests`;
CREATE TABLE `guests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(250) NOT NULL,
  `citizenship` varchar(200) NOT NULL,
  `dob` datetime NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `company` varchar(200) NOT NULL,
  `position` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `guests` (`id`, `fullname`, `citizenship`, `dob`, `contact_no`, `email`, `company`, `position`) VALUES
(4,	'Aman Jake L. Adriano',	'Filipino',	'2009-07-17 00:00:00',	'09184030903',	'secondrnd@gmail.com',	'Leon, Inc.',	'Baby'),
(5,	'Leon Thomas F. Adriano',	'Filipino',	'2009-07-17 00:00:00',	'0123456789',	'leonthomas@gmail.com',	'Leon, Inc.',	'Baby'),
(11,	'Rodellaine Flordeliza',	'Filipino',	'1982-09-10 00:00:00',	'09085422146',	'',	'',	'');

DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `checkinId` bigint(20) unsigned NOT NULL,
  `paymentDate` datetime NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `method` varchar(50) NOT NULL,
  `info` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `checkinId` (`checkinId`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`checkinId`) REFERENCES `checkins` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `reservations`;
CREATE TABLE `reservations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `guestId` bigint(20) unsigned NOT NULL,
  `checkin` datetime NOT NULL,
  `checkout` datetime NOT NULL,
  `roomType` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `guestId` (`guestId`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`guestId`) REFERENCES `guests` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `reservations` (`id`, `guestId`, `checkin`, `checkout`, `roomType`, `status`) VALUES
(1,	4,	'2013-01-09 17:39:12',	'2013-01-14 17:39:12',	'SINGLE',	'ACTIVE');

DROP TABLE IF EXISTS `rooms`;
CREATE TABLE `rooms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `roomNo` int(10) unsigned NOT NULL,
  `roomType` varchar(100) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `rooms` (`id`, `roomNo`, `roomType`, `description`) VALUES
(1,	1,	'DELUXE',	'1 Bed, Aircon, Tv, Bathroom'),
(2,	10,	'SINGLE',	'Single Bed, Good for 1 person only.');

-- 2013-01-17 22:43:07
